package LabExercise1;
import static org.junit.Assert.*;

import org.junit.Test;

public class Lab1_Ex1_CalculateSumTest {

	@Test
	public void test() {
		assertEquals(60,Lab1_Ex1_CalculateSum.calculateSum(15));
		
	}
	
	@Test
	public void test1(){
		assertEquals(90,Lab1_Ex1_CalculateSum.calculateSum(20));
	}

}
