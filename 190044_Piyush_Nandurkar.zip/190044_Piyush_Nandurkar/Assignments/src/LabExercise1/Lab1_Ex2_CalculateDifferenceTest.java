package LabExercise1;
import static org.junit.Assert.*;

import org.junit.Test;

public class Lab1_Ex2_CalculateDifferenceTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
