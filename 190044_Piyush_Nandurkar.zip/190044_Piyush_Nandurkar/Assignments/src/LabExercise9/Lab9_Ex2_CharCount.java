package LabExercise9;

import java.util.HashMap;
import java.util.Scanner;

public class Lab9_Ex2_CharCount {

	public static HashMap<String,Integer> getCount(char[] arr) {
		HashMap<String,Integer> hm = new HashMap<String,Integer>();
		for(char c : arr) {
			if(hm.containsKey(Character.toString(c))) {
				hm.replace(Character.toString(c), hm.get(Character.toString(c))+1);
			}
			else {
				hm.put(Character.toString(c), 1);
			}
		}
		return hm;
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of character array");
		int n = sc.nextInt();
		char[] arr = new char[n];
		for(int i=0;i<n;i++) {
			arr[i] = sc.next().charAt(0);
		}
		//map.toString().replace("=",":");
		System.out.println(getCount(arr).toString().replace("=", ":"));
		sc.close();
	}
}
