package LabExercise5;

import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class Lab5_Ex6_ValidateSalary {

	public static void validateSalary(double sal) throws EmployeeException {
		if(sal<3000) {
			throw new EmployeeException("Exception Raised : Salary Below 3000");
		}
		else
			System.out.println(sal);
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Salary");
		double sal = sc.nextDouble();
		try{
			validateSalary(sal);
		}
		catch(EmployeeException e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}
}
