package LabExercise5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Lab5_Ex4_ValidateName {
	static BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	static String name;
	public static void main(String[] args) throws NameException {
		try{
			System.out.println("Enter Name");
			name = br.readLine();
			if((name == null)||
	                (name.length() == 0)
	                    ||(name.trim().equals(""))){
	                throw new NameException("Blank Fields");
	            }
			
		}
		catch(NameException e) {
			e.getMessage();
			e.printStackTrace();
		}
		catch (IOException e) {
            e.printStackTrace();
        }
		
	}
}
