package LabExercise5;

import java.util.Scanner;

public class Lab5_Ex5_ValidateAge {

	public static void validateAge(int age) throws AgeException {
		if(age<15){
			throw new AgeException("Not Eligible");
		}
		else
			System.out.println("Age is : "+ age);
	}
	
	public static void main(String[] args) throws AgeException {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your age");
		int age = sc.nextInt();
		
		try{
			validateAge(age);
		}
		catch(AgeException e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		sc.close();
		
	}
}
