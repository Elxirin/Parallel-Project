package LabExercise8;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lab8_Ex3_WordCount {

	public static void main(String[] args) throws FileNotFoundException {
		BufferedReader reader  = new BufferedReader(new FileReader("C:\\Capgemini\\Workspace\\Classes\\src\\LabExercise8\\sample.txt"));
		String line;
		int lineCount=0,wordCount=0, charCount=0;
		try{
			line = reader.readLine();
			String[] words;
			char[] ch ;
			int i=1;
			while(line != null) {
				i++;
				lineCount++;
				words = line.split(" ");
				wordCount += words.length;
				for(String s : words) {
					charCount += s.length();
				}
				line = reader.readLine();
			}

		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Lines : "+ lineCount +" Words : "+wordCount+ " Characters : "+ charCount);
	}
}
