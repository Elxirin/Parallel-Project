package LabExercise8;

import java.util.Scanner;

public class Lab8_Ex7_ValidateName {

	public static boolean validate(String name) {
		String trail = name.substring(name.length()-4);
		if(trail.equals("_job"))
		{
			String[] parts = name.split("_");
			if(parts[0].length()>=8)
			{
				return true;
			}
		
		}
		
		return false;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Name for the Job");
		String name = sc.next();
		if(validate(name)){
			System.out.println("OK");
		}
		else
			System.out.println("Please Enter a valid name");
		sc.close();
	}
}
