package LabExercise8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Lab8_Ex2_LineNumber {

	public static void main(String[] args) throws IOException {
		BufferedReader reader  = new BufferedReader(new FileReader("C:\\Capgemini\\Workspace\\Classes\\src\\LabExercise8\\sample.txt"));
		String line;
		try{
			line = reader.readLine();
			
			int i=1;
			while(line != null) {
				System.out.print(i+ ". ");
				i++;
				System.out.println(line);
				line = reader.readLine();
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
