package LabExercise8;

import java.io.File;
import java.util.Scanner;

public class Lab8_Ex4_FileInfo {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the File Path");
		String fpath = sc.next();
		File file = new File(fpath);
		
		System.out.println(file.exists()?"File Exists":"File Does Not Exist");
		System.out.println(file.canRead()?"File is Readable":"File is Not Readable");
		System.out.println(file.canWrite()?"File is Writable":"File is Not Writable");
		System.out.println(file.isDirectory()?"It is a Directory":"It is not a Directory");
		System.out.println("The File is of "+getFileExtension(file)+" Type");
		System.out.println("Length of file :"+file.length());
		sc.close();
	}
	
	public static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }
}
