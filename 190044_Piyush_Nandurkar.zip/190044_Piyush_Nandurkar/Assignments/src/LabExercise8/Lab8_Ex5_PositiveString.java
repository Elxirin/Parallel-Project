package LabExercise8;

import java.util.Scanner;

public class Lab8_Ex5_PositiveString {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String str = sc.next();
		boolean flag=false;
		char[] carr = str.toCharArray();
		for(int i=0;i<carr.length-1;i++) {
			if((int)carr[i]>(int)carr[i+1]){
				flag=true;
				break;
			}
		}
		if(flag==true)
			System.out.println("Not a Positive String");
		else
			System.out.println("Positive String");
		sc.close();
	}
}
