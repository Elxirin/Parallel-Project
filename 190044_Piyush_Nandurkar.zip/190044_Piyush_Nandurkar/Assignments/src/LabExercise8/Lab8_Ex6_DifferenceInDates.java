package LabExercise8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Lab8_Ex6_DifferenceInDates {

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the date in dd/MM/yyyy format: ");
		String dateString = sc.nextLine();
		try{
		Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dateString);
		Date dateCurrent = new Date();
		System.out.print((date.getDate()-dateCurrent.getDate())<0?-(date.getDate()-dateCurrent.getDate())+ " Days  ":(date.getDate()-dateCurrent.getDate())+ " Days  ");
		System.out.print((date.getMonth()-dateCurrent.getMonth())<0?-(date.getMonth()-dateCurrent.getMonth())+" Months ":(date.getMonth()-dateCurrent.getMonth())+" Months ");
		System.out.print((date.getYear()-dateCurrent.getYear())<0?-(date.getYear()-dateCurrent.getYear())+" Years":(date.getYear()-dateCurrent.getYear())+ " Years");
		
		}
		catch(ParseException e) {
			e.printStackTrace();
		}
		
		sc.close();
	}
}
