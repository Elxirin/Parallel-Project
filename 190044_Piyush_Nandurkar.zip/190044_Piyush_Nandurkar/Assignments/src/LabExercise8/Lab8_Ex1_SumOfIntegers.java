package LabExercise8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex1_SumOfIntegers {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringTokenizer line = new StringTokenizer(sc.nextLine());
		int sum=0;
		while(line.hasMoreTokens()) {
			
			int c = Integer.parseInt(line.nextToken());
			sum += c;
			System.out.println(c);
		
		}
		
		System.out.println("Sum of all Integers is : "+ sum);
		sc.close();
		
	}
}
