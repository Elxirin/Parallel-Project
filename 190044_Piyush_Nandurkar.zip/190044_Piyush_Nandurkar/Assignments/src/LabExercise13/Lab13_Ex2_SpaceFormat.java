package LabExercise13;

import java.util.Scanner;

@FunctionalInterface
interface FormatSpace{
	void format(String name);
}

public class Lab13_Ex2_SpaceFormat {
	
	public static void main(String[] args) {
		FormatSpace fs = (name) -> {
			char arr[] = name.toCharArray();
			for(int i=0;i<arr.length;i++) {
				if(!(Character.toString(arr[i]).equals(" "))) {
					System.out.print(arr[i]+ " ");
				}
			}
		};
		System.out.println("Enter a String");
		Scanner sc = new Scanner(System.in);
		fs.format(sc.next());
		sc.close();
	}
}
