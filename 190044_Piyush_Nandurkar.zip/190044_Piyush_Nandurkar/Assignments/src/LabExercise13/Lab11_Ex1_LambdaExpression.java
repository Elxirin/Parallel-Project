package LabExercise13;

@FunctionalInterface
interface Power {
	double power(double x,double y);
}

public class Lab11_Ex1_LambdaExpression {
	public static void main(String[] args) {
		Power p = (x,y) -> {
			return Math.pow(x, y);
		};
		
		System.out.println(p.power(2, 8));
	}
}
