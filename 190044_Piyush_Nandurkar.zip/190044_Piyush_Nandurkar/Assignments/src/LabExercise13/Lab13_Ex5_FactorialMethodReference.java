package LabExercise13;

import java.util.function.IntConsumer;

public class Lab13_Ex5_FactorialMethodReference {

	public static void  factorial(int num) {
		int fact=1;

		while(num>0){
			fact = fact*num;
			num--;
		}
		
		System.out.println(fact);
		
	}
	
	public static void main(String[] args) {
		
		IntConsumer c = Lab13_Ex5_FactorialMethodReference::factorial;
		c.accept(5);
	}
}
