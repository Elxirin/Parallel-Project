package LabExercise11;


import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Executor_Test_6 { //Uses callable and Future 

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		//anonymous class implementation
				
		Callable<String> callable1 = new Callable<String>() {
			@Override
			public String call() throws Exception {
				System.out.println("Entered Callable1");
				Thread.sleep(2000);
				return "Task is done";
			}
		};
		
		Callable<String> callable2 = new Callable<String>() {
			@Override
			public String call() throws Exception {
				System.out.println("Entered Callable2");
				Thread.sleep(2000);
				return "Task is done";
			}
		};
		
		
		Callable<String> callable3 = new Callable<String>() {
			@Override
			public String call() throws Exception {
				System.out.println("Entered Callable3");
				Thread.sleep(2000);
				return "Task is done";
			}
		};
		
		
		System.out.println("Submitting Callable");
		List<Callable<String>> asList = Arrays.asList(callable1, callable2, callable3);
		List<Future<String>> invokeAll = executorService.invokeAll(asList);//submitting
		
		
		//This lines Executes Immediately
		System.out.println("Do something else While callable is getting executed");
		
		System.out.println("Retrieve the result form the Future");
		//Future.get() blocks until the result is available
		System.out.println(invokeAll);
		
		executorService.shutdown();
	}
}
