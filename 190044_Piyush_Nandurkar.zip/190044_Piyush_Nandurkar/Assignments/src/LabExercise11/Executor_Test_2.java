package LabExercise11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Executor_Test_2 {
	public static void main(String args[]) {
		System.out.println("Inside :" + Thread.currentThread().getName());

		System.out.println("Creating Executor Service with thread Pool of Size 2");
		ExecutorService executorservice = Executors.newFixedThreadPool(2);
		//ExecutorService executorservice = Executors.newSingleThreadExecutor();
		
		Runnable task1 = new Runnable() {
			@Override
			public void run() {
				System.out.println("Executing Task 1 inside :" + Thread.currentThread().getName());
				try{
					TimeUnit.SECONDS.sleep(2);
				}
				catch(InterruptedException e) {
					throw new IllegalStateException(e);
				}
			}
		};
		
		Runnable task2 = new Runnable() {
			@Override
			public void run() {
				System.out.println("Executing Task 2 inside :" + Thread.currentThread().getName());
				try{
					TimeUnit.SECONDS.sleep(4);
				}
				catch(InterruptedException e) {
					throw new IllegalStateException(e);
				}
			}
		};
		
		Runnable task3 = new Runnable() {
			@Override
			public void run() {
				System.out.println("Executing Task 3 inside :" + Thread.currentThread().getName());
				try{
					TimeUnit.SECONDS.sleep(3);
				}
				catch(InterruptedException e) {
					throw new IllegalStateException(e);
				}
			}
		};
		
		System.out.println("Submitting the Task for Execution");
		executorservice.submit(task1);
		executorservice.submit(task2);
		executorservice.submit(task3);
		
		System.out.println("Shutting Down Executor");
		executorservice.shutdown();
	}
}
