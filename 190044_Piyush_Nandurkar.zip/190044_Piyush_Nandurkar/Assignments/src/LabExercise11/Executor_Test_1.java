package LabExercise11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Executor_Test_1 {
public static void main(String args[]) {
 System.out.println("Inside :" + Thread.currentThread().getName());

 System.out.println("Creating Executor Service with single worker thread:");
 //Executor executor = Executors.newSingleThreadExecutor();
  ExecutorService executorservice=Executors.newSingleThreadExecutor();

 
  System.out.println("Creating a Runnable...");
  /*
  * Runnable task=newRunnable()
  * { public void run(){
  * System.out.println("Inside :"+Thread.currentThread().getName());
  * 
  * } };
  */
 Runnable task = () -> System.out.println("Inside :" + Thread.currentThread().getName());

 System.out.println("Submit the task specified by runnable to the executor");
 //executor.execute(task);
 executorservice.submit(task);

 System.out.println("Shutting down the executor");
 executorservice.shutdown();
}
}
