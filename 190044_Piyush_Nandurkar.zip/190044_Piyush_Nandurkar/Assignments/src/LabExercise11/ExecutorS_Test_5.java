package LabExercise11;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorS_Test_5 { //Uses callable and Future 

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		//anonymous class implementation
				
		Callable<String> callable1 = new Callable<String>() {
			@Override
			public String call() throws Exception {
				System.out.println("Entered Callable");
				Thread.sleep(2000);
				return "Task is done";
			}
		};
		
		
		System.out.println("Submitting Callable");
		Future<String> future = executorService.submit(callable1);
		
		//This lines Executes Immediately
		System.out.println("Do something else While callable is getting executed");
		
		System.out.println("Retrieve the result form the Future");
		//Future.get() blocks until the result is available
		String result = future.get();
		System.out.println(result);
		executorService.shutdown();
	}
}
