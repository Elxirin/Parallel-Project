package LabExercise10;

import java.util.Scanner;

public class FileProgram {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String source = sc.next();
		String target = sc.next();
		
		Thread t1 = new CopyDataThread("Copy Data",source,target);
		t1.start();
		
		sc.close();
	}
}
