package LabExercise10;

public class Timer implements Runnable {
	private boolean doStop = false;
	
	public synchronized void doStop() {
		this.doStop = true;
	}
	
	public synchronized boolean keepRunning() {
		return this.doStop == false;
	}
	
	public static void main(String[] args) {
		System.out.println("*RunnableThread Timer :-> Started");
	
		Thread timer = new Thread(new Timer());
		timer.start();
	}
	
	@Override
	public void run() {
		while(keepRunning()) {
			//Keep doing what this thread should do.
			for(int i =10 ;i>=1;i--)
			{
				System.out.println(i);
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
