package LabExercise10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread{
	
	public String source,target;
	
	public CopyDataThread(String threadName, String source, String target) {
		super(threadName);
		this.source = source;
		this.target = target;
	}
	private boolean doStop = false;
	@Override
	public void run() {
		File srcFile = new File(source);
		File trgtFile = new File(target);
		System.out.println("Copying Started......");
		try {
			FileInputStream fileInput = new FileInputStream(srcFile);
			FileOutputStream fileOutput = new FileOutputStream(trgtFile);
			int input = 0;
			int count =1;
			input = fileInput.read();
			while(input != -1) {
				while(count!=10) {
					if(input == -1)
						break;
					fileOutput.write(input);
					input = fileInput.read();
					count++;
				}
				count = 0;
				System.out.println("10 Characters are Copied");
				Thread.sleep(5000);
			}
			
			System.out.println("Successfully Copied");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
	}
}
