package com.bank.main;
import java.util.Scanner;

import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;
import com.bank.service.BankService;
public class MainUi {
	public static void Menu()
	{
		System.out.println("\n\n\n*************BANK APPLICATION***************");
		System.out.println("*********************************************************");
		System.out.println("1. CreateAccount\n2. Show Balance\n3. Deposit\n4. WithDraw\n5. Fund Transfer\n6. Print Transaction\n7. Exit");
	}
	public static void main(String[] args) throws InvalidException {
		do{
			Menu();
		
		 Scanner sc=new Scanner(System.in);
		 BankService bankService=new BankService();
		 BankDetails bankDetails=new BankDetails();
		 TransactionDetails transactionDetails=new TransactionDetails();
	 int opt=sc.nextInt();
		 
	 switch(opt)
	 {
	 case 1:
		 System.out.println("Fill the reqiured details to create Account\n");
		 System.out.println("Enter Account Name");
		 String name=sc.next();
		 if(name==null||name.length()>12)
		 {
			 throw new InvalidException("Enter valid Name ");
		 }
		 System.out.println("Enter Mobile Number");
		 String mobileno=sc.next();
		 if(mobileno.length()!=10)
		 {
			 throw new InvalidException("Enter valid Mobile Number");
		 }
		 
		 bankDetails.setAccId();
		 bankDetails.setAccountantName(name);
		 bankDetails.setMobileno(mobileno);
		 bankDetails.setAccBalance(1000);
		 
		 
		 bankService.CreateAccount(bankDetails);		//Service class calling
		 
		 System.out.println("Inserted Successfully ......");
		 int id=bankDetails.getAccId();
		 bankService.getAccountById(id);
		 System.out.println("Your ACCOUNT ID is :"+bankDetails.getAccId());
		 
		 System.out.println("-------------------------------------------------------------");
	  break;
	 case 2:
		 System.out.println("Enter your account id for Balance enquiry");
		 int accid=sc.nextInt();
		 if(accid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bankDetails=bankService.getAccountById(accid);
		 System.out.println("Accountant Name: "+bankDetails.getAccountantName());
		 System.out.println(" YOur Account Balance is: "+bankDetails.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------");
		 break;
		 
	 case 3:
		 System.out.println("Deposit Module...!!");
		 System.out.println("Enter your Account ID");
		 int depId=sc.nextInt();
		 if(depId==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bankDetails=bankService.getAccountById(depId);	
		 System.out.println("Accountant Name: "+bankDetails.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bankDetails.getAccBalance());
		 int initbal=bankDetails.getAccBalance();
		 System.out.println("Enter the Amount you want to Deposit");
		 int depAmt=sc.nextInt();
		 int finalbal=initbal+depAmt;
		 bankDetails.setAccBalance(finalbal);
		 bankService.Deposit(bankDetails);

		 //Updating In Transaction Table
		 
		 transactionDetails.setTransactionType("Deposit");
		 transactionDetails.setAccId(depId);
		 transactionDetails.setAmount(depAmt);
		 bankService.addTransaction(transactionDetails);
		 bankDetails.setT(transactionDetails);
		 
		 
		 bankDetails=bankService.getAccountById(depId);
		 System.out.println("Hello  "+bankDetails.getAccountantName());
		 System.out.println("Your Account Balance after Depositing "+depAmt+" Rs is "+bankDetails.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
	 case 4:
		 System.out.println("Withdraw Module");
		 System.out.println("Enter your account Id");
		 int wid=sc.nextInt();
		 if(wid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bankDetails=bankService.getAccountById(wid);						
		 System.out.println("Hello... "+bankDetails.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bankDetails.getAccBalance());
		 int intbal=bankDetails.getAccBalance();							//initial balance
		 System.out.println("-------------------------------------------");
		 System.out.println("Enter the Amount you want to Withdraw");
		 int wamt=sc.nextInt();
		 int finalBal=intbal-wamt;
		 bankDetails.setAccBalance(finalBal);
		 bankService.Withdraw(bankDetails);
 		 
 		 
		 //Updating In Transaction Table
		 transactionDetails.setTransactionType("Withdraw");
		 transactionDetails.setAccId(wid);
		 transactionDetails.setAmount(wamt);
		 bankService.addTransaction(transactionDetails);
		 bankDetails.setT(transactionDetails);
		 
		 bankDetails=bankService.getAccountById(wid);
		 System.out.println("Hello ................ "+bankDetails.getAccountantName());
		 System.out.println("Your Remaining Account Balance after Withdraw "+wamt+" Rs is"+bankDetails.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
	 case 5:
		 System.out.println("Fund Transfer....!!");
		 System.out.println("Enter the From Account ID");
		 int fid=sc.nextInt();	//From Account Id (Sender)
		 if(fid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bankDetails=bankService.getAccountById(fid);
		 int bal=bankDetails.getAccBalance();						//Initial Balance
		 System.out.println("Enter the amount you want to transfer");
		 int fund=sc.nextInt();	//Amount to be transfered
		 System.out.println("Enter Reciever Account Id");
		 
		 int tid=sc.nextInt();
		 if(tid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 
		//Removing the Balance transfered from sender Account 
		 bankDetails=bankService.getAccountById(fid);
		 int bal1=bal-fund;
		 bankDetails.setAccBalance(bal1);
		 bankService.Deposit(bankDetails);
		 
		 //updating the Balance recieved from Sender
		 bankDetails=bankService.getAccountById(tid);
		 int tbal=bankDetails.getAccBalance();
		 int tbalance=tbal+fund;
		 bankDetails.setAccBalance(tbalance);
		 bankService.Deposit(bankDetails);
		
		 
		 //updating In transaction Table
		 transactionDetails.setTransactionType("Transfered to "+tid);
		 transactionDetails.setAccId(fid);
		 transactionDetails.setAmount(fund);
		 bankService.addTransaction(transactionDetails);
		 bankDetails.setT(transactionDetails);
		 int a= transactionDetails.getTransactionId();
		
		 bankDetails=bankService.getAccountById(fid);
		 System.out.println("helooo...."+bankDetails.getAccountantName());
		 System.out.println("Remaining balance in account "+bankDetails.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
		 
	 case 6:
		System.out.println("Print Transaction");
		System.out.println("Enter the account id");
		int trid=sc.nextInt();
		bankService.PrintTransactions(trid);
		 System.out.println("\n\n-------------------------------------------------------------");
		 break;
	 case 7:
		 System.out.println("Thankyou For using our Bank Services...................!!!");
		 System.exit(0);
	 }
	}while(true);
}
}