import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Transaction } from '../../models/Transaction.model';
import { WalletService } from 'src/app/services/wallet.service';
import { SampleResponse } from 'src/app/models/SampleResponse.model';
@Component({
  selector: 'app-show-transactions',
  templateUrl: './show-transactions.component.html',
  styleUrls: ['./show-transactions.component.css']
})
export class ShowTransactionsComponent implements OnInit {
  transactionForm: FormGroup;
  response: SampleResponse;
  constructor(private service: WalletService, private formBuilder: FormBuilder) {
  }
  ngOnInit() {
    this.transactionForm = this.formBuilder.group({
      accountNum: ['', [Validators.required, Validators.pattern("^[A-Z]{3}\\d{10}$")]],
      password: ['', Validators.required]
    });
  }
  get formControls() { return this.transactionForm.controls; }
  onSubmit() {
    if (this.transactionForm.invalid) {
      return;
    }
    let accountNum: string = this.formControls.accountNum.value;
    let password: string = this.formControls.password.value;
    this.transactions(accountNum, password);
  }
  transactions(accountNum: string, password: string) {
    this.service.transactions(accountNum, password).then(response => { this.response = response;}
      , err => {
        if (err.success != undefined && err.success == false) {
          this.response = err;
        }
      });
  }
}
