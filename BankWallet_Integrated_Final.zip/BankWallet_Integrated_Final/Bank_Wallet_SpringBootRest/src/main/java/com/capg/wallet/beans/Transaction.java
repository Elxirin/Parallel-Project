package com.capg.wallet.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * contains all the properties related to a transaction.
 */
@Entity
@Table(name = "bank_wallet_transaction_tab")
public class Transaction {
	@Id
	@Column(name = "tran_id")
	private String id;
	@Column(name = "tran_time")
	private Date time;
	@Column(name = "tran_acc_to")
	@JsonProperty(value="to-account")
	private String accountTo;
	@Column(name = "tran_amount")
	private double amount;
	@Column(name = "tran_remark")
	private String remark;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "tran_acc_from")
	@JsonIgnore
	private Account accountFrom;

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", time=" + time + ", accountTo=" + accountTo + ", amount=" + amount
				+ ", remark=" + remark + ", accountFrom=" + accountFrom.getAccountNumber() + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public Account getAccountFrom() {
		return accountFrom;
	}

	public void setAccountFrom(Account accountFrom) {
		this.accountFrom = accountFrom;
	}

	public String getAccountTo() {
		return accountTo;
	}

	public void setAccountTo(String accountTo) {
		this.accountTo = accountTo;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Transaction() {
		super();
	}
}
