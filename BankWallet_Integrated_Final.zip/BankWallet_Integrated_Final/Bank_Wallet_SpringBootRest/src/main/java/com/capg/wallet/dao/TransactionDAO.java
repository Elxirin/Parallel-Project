package com.capg.wallet.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.wallet.beans.Account;
import com.capg.wallet.beans.Transaction;

@Repository
public interface TransactionDAO extends JpaRepository<Transaction, String> {
	List<Transaction> findTransactionByAccountFrom(Account account);
}
