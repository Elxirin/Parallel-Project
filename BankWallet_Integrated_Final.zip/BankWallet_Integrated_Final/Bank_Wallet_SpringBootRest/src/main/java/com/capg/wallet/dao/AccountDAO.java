package com.capg.wallet.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.wallet.beans.Account;

/*
 * interface for WalletDaoImpl,contains the methods that must be implemented in the child class.
 */
@Repository
public interface AccountDAO extends JpaRepository<Account, String> {
	@Query("select a.balance from Account as a where a.accountNumber=?1 and a.password=?2")
	double getBalance(String accountNum, String password);

}
